

<!DOCTYPE html>
<html lang="en">
<head>

    <title>Igniteble Articles</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="Igniteble" />
    <meta name="author" content="Igniteble">
    <meta charset="UTF-8" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    
	<link rel="icon" type="image/ico" href="images/favicon.png" />
    
    
    
    <link href="css/bootstrap.min.css" rel="stylesheet" />    
    <link href="style.css" rel="stylesheet" />
    
    
	
    
    
    <link rel="stylesheet" href="css/prettyPhoto.css" type="text/css" media="screen" />    
	<link href="css/jquery.bxslider.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <link rel="icon" type="image/ico" href="favicon.ico" />
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700' rel='stylesheet' type='text/css' />    
    <link href='http://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
   
</head>

<body data-spy="scroll" data-target=".navbar" data-offset="75">


	
	<!-- Preloader 
	<div class="mask"><div id="loader"></div></div>
	Preloader -->
    
    
    
    

 


	<!-- Navigation -->
    <div id="navigation" class="navbar navbar-fixed-top">
		 
	
		<div class='navbar-inner '>
        	<div class='container no-padding'>
				
					<a class='show-menu' data-toggle='collapse' data-target='.nav-collapse'>
						<span class='show-menu-bar'></span>
					</a>
                    
					<div id='logo'><a  href='index.php#navigation'></a></div>
					<div class='nav-collapse collapse'>
						<ul class='nav'>
						
				
							<li class='menu-1'><a class='colapse-menu1' href='/index.php#home'>Home</a></li>				
							<li class='menu-2'><a class='colapse-menu1' href='/index.php#managed'>Managed Service</a></li>							
							<li class='menu-3'><a class='colapse-menu1' href='/index.php#messaging'>Mobile Messaging</a></li>
							<li class='menu-4'><a class='colapse-menu1' href='/index.php#analytics'>Analytics</a></li>

							<li class='menu-5'><a class='colapse-menu1' href='/index.php#contact'>Contact</a></li>
							<li class='menu-6'><a  class='colapse-menu1' href='/news.php#news'>News</a></li>
							<li class='menu-7'><a  style='color: #418ed6;' class='colapse-menu1' href='/articles.php'>Articles</a></li>	
 																				 			

    
						</ul>
					</div>
				</div>
			</div>
  			
 	</div>
    <!--/Navigation -->
    
    
    
    
    
    
    <!-- Blog Header -->
    <div id="blog-header">
    
    	<h1>Articles </h1>
    
    </div>
    <!--/Blog Header -->
    
    
    
    
    
    <!-- Blog Content -->
    <div id="blog" class="clearfix">
    	
        <!-- Container -->
    	<div class="container">
        
        
        
        
            
            
            <!-- Blog Posts Content -->
    		<div class="blog-posts-content">
            
   
   <!-- Article 1 //-->
   
   
   
      
                     <!-- Blog Post -->
               
            	<div class="blog-post" id="N20160931">
                
                	<div class="type-date">                    
                    	<div class="blog-type"><img src="images/blog-quote.png" alt=""></div>
                        <div class="blog-date"><h5>Aug.</h5><h5>31</h5></div>                    
                    </div>
                	
                    
                    
                    <!-- Post Content -->
                	<div class="post-content">
                    
                    
                    
                     	<div class="post-slider">                        
                            <ul class="blog-slider">                            
                                <li><a href="#" target="_blank"><img src="http://igniteble.com/images/blog-Igniteble-Driving-Engagement-Experience-and-Revenue-2.jpg" alt="The Rise of the Mobile Marketer"></a></li>  
                                <li><a href="#" target="_blank"><img src="http://igniteble.com/images/blog-Igniteble-Driving-Engagement-Experience-and-Revenue-1.jpg" alt="The Rise of the Mobile Marketer"></a></li>                                                           
                            </ul>                        
                        </div>
                        
                    
                            
                        <h3 class="blog-title">Marketers Seize the Customer Experience</h3>
             

                        
                        <div class="blog-content">
                        
 <i>
 This article is drawn from an Economist Intelligence Unit report.  The report was supported by a survey that included responses from 499 chief marketing officers and senior marketing executives worldwide
 </i>                           
                             
                            

<h4>Chief Marketing Officers will own the customer experience.</h4>


					<div class="skills"  style="margin:10px 0 -30px 0;">
						<ul class="bar">
                        
                            <li>
                                <div class="bar-wrap"><span data-width="86"><strong>86% of CMOs believe they will own the end-to-end experience</strong></span></div>
                            </li> 

                             
						</ul>
					</div>	

Eighty-six percent of CMOs and senior marketing executives believe they will own the end-to-end customer experience by 2020. The EIU explored this trend last year in <b><i>The Rise of the Marketer: Driving Engagement, Experience and Revenue.</i></b>
<br><br>
The top channels to the customer in 2020 will be social media (63% of respondents), the Internet (53%), mobile apps (47%) and mobile web (46%)
<br><br>
  
					<div class="skills" style="margin:10px 0 -30px 0;">
					<h4>Future innovation will focus on:</h4><br>
						<ul class="bar">
                        
                            <li>
                                <div class="bar-wrap"><span data-width="59"><strong>mobile (59%)</strong></span></div>
                            </li> 
                            <li>
                                <div class="bar-wrap"  ><span data-width="45"><strong>personalization (45%)</strong></span></div>
                            </li> 


                             
						</ul>
					</div>	
    

Future innovation will focus on small screens and no screens. Mobile devices (59%), personalization technologies (45%) are the two technology-specific trends that will have the biggest impact on marketing organizations by 2020.
<br><br>
Today, the primary task of CMOs is to deeply understand customer buying behavior and intent; deeply understand the context of where someone is in their decision journey; be able to predict what they’re most likely primed to do next; and be ready to influence them at the right moment.  CMOs will reorganize their departments around data, and analytics, personalized customer experiences as a core strategy for creating and growing the value of brands.
<br><br>
The survey data suggest there is not a lot of time for CMOs to get things right. Survey respondents agree that marketing complexity has picked up speed and scale. When asked to compare which trends in the business environment will change marketing practice the most by 2020, respondents listed the accelerating pace of technology change, mobile lifestyles and the explosion of potential marketing channels as their top three choices. The specific technology trends that are driving those business environment changes by 2020 are mobile devices and networks, personalization technologies and the Internet of Things.
<br><br>
According to the CMO Council, personalization blends a deep understanding of a customer’s wants, needs and desires with timely and tailored delivery of relevant content, products and services.
<br><br>
However, when marketers are asked about the top three channels for customers in 2020, social media increases sharply for marketers, while the World Wide Web declines. <h5>By 2020, mobile apps and mobile web will overtake e-mail as a top channel to the customer.</h5>  This suggests that by 2020, more marketers expect they will interact directly with their customers through technology and personalization than interact indirectly with their customers through media and advertising.
<br><br>
Customers typically show up at a brand’s front door—physical or virtual—already well educated about what a brand potentially offers them. This changes how a CMO positions marketing resources and assets. “You’re no longer marketing AT people,” says Ms Lemkau. “You’re influencing them in an environment where they’ve already had a chance to form a view.”
<br><br>
  
					<div class="skills" style="margin:10px 0 -30px 0;">
						<ul class="bar">
                        
                            <li>
                                <div class="bar-wrap"><span data-width="90"><strong>By 2020, almost 90% of marketing dept. will drive business strategy.</strong></span></div>
                            </li> 

                             
						</ul>
					</div>	
CMOs have become laser-focused on CX because it directly hits both the top and bottom lines of business.  Moreover, nearly 90% of survey respondents believe marketing departments will exercise significant influence over business strategy by 2020, while nearly 80% say marketers will exercise the same influence over technology.
<br><br>
Elevating a personalized, efficient and consistent customer experience requires that CMOs integrate multiple departmental agendas under a single umbrella. Most CMOs readily admit that this is often a long, tough slog. But in the same breath, they acknowledge that better customer experience is the foundation for business performance.
<br><br>
By 2020, revenue impact remains the top metric, with every other measure playing a more or less equal role in a suite of measuring capabilities.
<br><br>


  
                          
                                         
                        </div>
 
                    </div>
                	<!--/Post Content -->
                    
        
            
            
                   
   
   
   <!-- Article 2 //-->
 <section id="mobilematters">  
 
                     <!-- Blog Post -->
               
            	<div class="blog-post" id="N20160527">
                
                	<div class="type-date">                    
                    	<div class="blog-type"><img src="images/blog-quote.png" alt=""></div>
                        <div class="blog-date"><h5>May</h5><h5>27</h5></div>                    
                    </div>
                	
                    
                    
                    <!-- Post Content -->
                	<div class="post-content">
                    
                    
                    
                     	<div class="post-slider">                        
                            <ul class="blog-slider">                            
                                <li><a href="http://www.phunware.com/blog/mobile-stat-snack-90-of-mobile-time-spent-in-apps/" target="_blank"><img src="http://igniteble.com/images/blog-stat-snack-mboile-time-spent.png" alt="90% of time on mobile is spent in Apps"></a></li>                            
                            </ul>                        
                        </div>
                        
                    
                            
                        <h3 class="blog-title">Mobile Matters</h3>
             

                        
                        <div class="blog-content">
                        
                            
                             
                            

<h4>Lets finally admit that consumers’ everyday lives rely on mobile.</h4>

According to data released by ComScore in April 2016, smartphone penetration in the US is now at 80%.<br><br>

Consumers average 40 to 70 apps on their smartphone and the U.S. is far and away the highest consumer of monthly data, spending a staggering 4.7 hours per day on their smartphone and approximately 80% of that time (3.7 hours) on mobile apps (including mobile web browsing).  This means that we spend approximately 20% of our waking hours on apps. Sure, using your smartphone isn’t mutually exclusive with completing other activities, but still, 3.7 hours is a significant chunk of the day.<br><br>

<ul>
<li> + <b>23 percent of apps are used only once</b></li>
<li> + <b>52 percent of users view push messages as annoying</b></li>
<li> + <b>Half of consumers trust their mobile operators and brands less than they did three years ago</b></li>

</ul>

<br>


An August 2015 Millward Brown Digital survey revealed that 43% of US smartphone owners used 4 to 6 apps on an average day.  The same study found that 72% of smartphone owners deleted an app because they rarely used it.  Other causes of deletion were because the app was draining the device’s battery, as well as a need to free up memory on their smartphone.  Looking to combat deletion and lack of usage, many app marketers have been turning to app retention, a metric used to gauge how valuable an app is to consumers.<br><br>

The corporate decision regarding mobile web vs native app is a complex strategic endeavor.  To be sure, not all consumer facing companies can justify a highly developed mobile app.  However, businesses are not re-imagining their mobile experience fast enough. The vast majority of businesses have failed to innovate at anywhere near the same pace of consumers’ demands and expectations for mobile.  Better connectivity, more and smarter devices plus the proliferation of apps means that consumers’ everyday lives are now mobile.  Multitudes of businesses will fail if they don’t drastically change their approach to meet and exceed consumers’ mobile expectations.<br><br>

Mobile is fundamentally different than the Web, and it needs to become part of an organization’s DNA. It provides the opportunity for a bi-directional, real-time, interactive relationship with end users - however most companies simply aren’t taking advantage of this yet.<br><br>

Innovation feels like it has a shelf life of zero.  The user journey is no longer linear. Marketing now plays the leading role in customer relationships. Big data has become a scary word, instead of one that helps makes sense of the complexity.  All these changes have brought us to this tipping point, where many forces are shaping how businesses react.<br><br>

In the gold mine that is mobile, we need to take advantage of the insights and engagement opportunities that have been provided to us.  If we do this, the promise of mobile will be fulfilled.  We will have developed the immersive relationships that consumers’ demand today and tomorrow.<br><br>

We cannot improve mobile engagement unless we take advantage of the deep insights from the data that users are readily sharing with us.  They are giving us all of the information we need, but it’s only powerful if we act on it.  And we cannot make sense of those insights unless we truly understand who our users are and how to engage them.




  
                          
                                         
                        </div>
 
                    </div>
                	<!--/Post Content -->
 </section>
 
 
                    
                </div>
                 
            	<!-- Blog Post -->          
            
            
                            
                
            
            
            

            
            
            
            
    
            
            
            
            

            
            
            
 
             </div>
            <!--/Blog Posts Content -->
            
            
            
            
            
            <!-- Sidebar -->
            <div id="sidebar">
            

 
                 <!-- Twitter Widget -->
                <div class="widget   clearfix">
                    
                	<div class="heading"><h5>Twitter Feed</h5></div>		
                
           
<a class="twitter-timeline"  href="https://twitter.com/igniteBLE"  data-widget-id="491028199761903616">Tweets by @igniteBLE</a>
    <script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+"://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>


                    
                </div>
            	<!--/Twitter Widget -->

            
            </div>
            <!--/Sidebar -->          





            
        
        </div>
    	<!--/Container -->
        
        
        
        
 
        
        
        
        
        
        
    </div>
    <!--/Blog Content -->
    
    
    
    
    
    <!-- Blog Navigation -->
    <div id="blog-footer" class="clearfix">
    	
        <!--/Container  
        <div class="container no-padding">
        
        	<ul class="inner-navigation masonry">
            
            	<li><a href="#"><span><img src="images/prev_article.png" alt=""></span>Prev Page</a></li>
                <li><a href="#"><span><img src="images/next_article.png" alt=""></span>Next Page</a></li>
            
            </ul>
        
    	</div>
    	 /Container -->
    
    </div>
    <!--/Blog Navigation -->
    
    
    
    
    
    <!-- ALL ICON IMAGES
    
    <img src="images/blog-gallery.png" alt=""> <img src="images/blog-quote.png" alt=""> <img src="images/blog-video.png" alt=""> <img src="images/blog-text.png" alt=""> <img src="images/blog-image.png" alt=""> 
    //-->
    
    
    
    
    
 

	<!-- Contact Section -->
	<section id="contact">
		
        <!-- Container -->
		<div class="container small-width" style="margin-top:60px;">
			
            <!-- Section Title -->
            <div class="section-title"  style="margin-top:60px;">
                <h1>Sign up to receive next installment:</h1>
                <h4>“Elements of a Positive User Experience”</h4><br>
                <span class="border"></span>
                

            </div>				
			<!--/Section Title -->
            
            	<div>
            	<!--
                <div class="one_half">
                <p><strong>Want to learn more?</strong> <br>Sign up to receive the next articles.</p>
                </div>
                //-->
                </div>
                <div style="clear:both;"></div>
            
            
			<!-- Contact Formular -->
			<div id="contact-formular">
            
            	<div id="message"></div>
            
                <form method="post" action="directsubscribe.php" name="contactform" id="contactform">
                
                <div class="one_half element_from_left">            
                    <input name="name"  type="text" id="name"  size="30"  onfocus="if(this.value == 'Name') { this.value = ''; }" onblur="if(this.value == '') { this.value = 'Name'; }" value="Name" >
                    <input name="email" type="text" id="email" size="30"  onfocus="if(this.value == 'E-mail') { this.value = ''; }" onblur="if(this.value == '') { this.value = 'E-mail'; }" value="E-mail" >                
                    <input name="phone" type="text" id="phone" size="30"  onfocus="if(this.value == 'Phone') { this.value = ''; }" onblur="if(this.value == '') { this.value = 'Phone'; }" value="Phone" >
                    <div class="quota"><input name="supermsg"   type="text" id="supermsg"   size="30" value="super"></div>          
                </div>
                
                <div class="one_half last element_from_right">            
                    <textarea name="comments" cols="40" rows="4" id="comments" onfocus="if(this.value == 'Message') { this.value = ''; }" onblur="if(this.value == '') { this.value = 'Message'; }" >Company and Title or Role</textarea>            
                </div>            
                
                <input type="submit" class="send_message" id="submit" value="Subscribe to next article" />
    			
    
    
                </form>
                
            </div>
  			<!--/Contact Formular -->
            
        </div> 
        <!--/Container --> 
        
        
        <!-- Map 
        <div id="map_canvas"></div>
         End Map-->
        
        
        
	</section>
	<!--/Contact Section -->
   
    
    
    
    
    <!-- Footer -->
    <footer>
				<div class="container no-padding">
        	
            <a id="back-top"><div id="menu_top"><div id="menu_top_inside"></div></div></a>
            
            <ul class="socials-icons">
                <li><a target="_blank" href="http://facebook.com/Igniteble"><img src="/images/facebook.png" alt="" /></a></li>
                <li><a target="_blank" href="http://twitter.com/Igniteble"><img src="/images/twitter.png" alt="" /></a></li>
               
            </ul> 
            
			<p class="copyright">Interface Proximity | Igniteble, LLC - All rights reserved.  
				
				&copy; 2014<script>new Date().getFullYear()>2011&&document.write("-"+new Date().getFullYear());</script>  | <a href="/end-user-privacy-policy.php">End User Mobile App Privacy Policy</a> | <a href="/interface/index.php">Log In</a></p>
            
		</div>	</footer>
	<!-- Footer -->
    

    
	
	<script src='http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.js'></script>
    <script src="js/jquery.sticky.js"></script>	    
	<script src="js/jquery.easing-1.3.pack.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/jquery.parallax-1.1.3.js" type="text/javascript"></script>
	<script src="js/appear.js" type="text/javascript" ></script>
	<script src="js/modernizr.js" type="text/javascript"></script>
	<script src="js/jquery.prettyPhoto.js" type="text/javascript"></script>
    <script src="js/isotope.js" type="text/javascript"></script>
    <script src="js/jquery.bxslider.min.js"></script>
    <script src="js/jquery.cycle.all.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/jquery.maximage.js" type="text/javascript" charset="utf-8"></script>
    <script src="js/sscr.js"></script>
    <script src="js/skrollr.js"></script>
    <script src="js/jquery.jigowatt.js"></script>
    <script src="http://maps.google.com/maps/api/js?sensor=false" type="text/javascript"></script>    
	<script src="js/scripts.js" type="text/javascript"></script>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-6770565-26', 'auto');
  ga('send', 'pageview');

</script>    
    
	
	
	</body>
</html>