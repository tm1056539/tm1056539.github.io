
<!DOCTYPE html>
<html lang="en">
<head>

    <title>Igniteble</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="Igniteble" />
    <meta name="author" content="Igniteble">
    <meta charset="UTF-8" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    
	<link rel="icon" type="image/ico" href="images/favicon.png" />
    
    
    
    <link href="css/bootstrap.min.css" rel="stylesheet" />    
    <link href="style.css" rel="stylesheet" />
    
    
	
    
    
    <link rel="stylesheet" href="css/prettyPhoto.css" type="text/css" media="screen" />    
	<link href="css/jquery.bxslider.css" rel="stylesheet" />
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <link rel="icon" type="image/ico" href="favicon.ico" />
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700' rel='stylesheet' type='text/css' />    
    <link href='http://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
   
</head>

<body data-spy="scroll" data-target=".navbar" data-offset="75">


	
	<!-- Preloader 
	<div class="mask"><div id="loader"></div></div>
	Preloader -->
    
    
    
    

 


	<!-- Navigation -->
    <div id="navigation" class="navbar navbar-fixed-top">
		 
	
		<div class='navbar-inner '>
        	<div class='container no-padding'>
				
					<a class='show-menu' data-toggle='collapse' data-target='.nav-collapse'>
						<span class='show-menu-bar'></span>
					</a>
                    
					<div id='logo'><a  href='index.php#navigation'></a></div>
					<div class='nav-collapse collapse'>
						<ul class='nav'>
						
				
							<li class='menu-1'><a class='colapse-menu1' href='/index.php#home'>Home</a></li>				
							<li class='menu-2'><a class='colapse-menu1' href='/index.php#managed'>Managed Service</a></li>							
							<li class='menu-3'><a class='colapse-menu1' href='/index.php#messaging'>Mobile Messaging</a></li>
							<li class='menu-4'><a class='colapse-menu1' href='/index.php#analytics'>Analytics</a></li>

							<li class='menu-5'><a class='colapse-menu1' href='/index.php#contact'>Contact</a></li>
							<li class='menu-6'><a  class='colapse-menu1' href='/news.php#news'>News</a></li>
							<li class='menu-7'><a  class='colapse-menu1' href='/articles.php'>Articles</a></li>	
 																				 			

    
						</ul>
					</div>
				</div>
			</div>
  			
 	</div>
    <!--/Navigation -->
    
    
    
    
    
    
    <!-- Blog Header -->
    <div id="blog-header">
    
    	<h1>End User Mobile App Privacy Policy </h1>
    
    </div>
    <!--/Blog Header -->
    
    
    
    
    
    <!-- Blog Content -->
    <div id="blog" class="clearfix">
    	
        <!-- Container -->
    	<div class="container">
        
        
        
        
            
            
            <!-- Blog Posts Content -->
    		<div class="blog-posts-content">
            
            
            
            
                  <!-- Blog Post -->
               
            	<div class="blog-post" id="N20150210">
                
        
                    
                    
                    <!-- Post Content -->
                	<div class="post-content">
                    
                    
                    
 
                        
                    
                            
                        <h3 class="blog-title">PRIVACY POLICY </h3>
                        

                        
                        <div class="blog-content">
                        






This privacy policy governs your use of the software application: Interface Proximity Tool (“Application”) for mobile devices that was created by Ignite BLE, LLC. The Application is designed to provide meaningful information and a more personalized experience to you, based on your behavior, location and interaction with the Application. This privacy policy describes how we collect and use the information collected through the Interface Proximity Application.  The policy will provide the privacy options available to you for the use of your information.<br><br>
 
<h4>What information does the Application obtain and how is it used?</h4>
<h5>User Provided Information </h5>
The Application obtains the information you provide when you download and register the Application. Registration with us is optional. However, please understand that you may not be able to use some of the features offered by the Application unless you register with us.
When you register with us and use the Application, you generally provide (a) your name, email address, age, user name, password and other registration information; (b) transaction-related information, such as when you redeem offer, respond to any information, or download or use applications from us; (c) information you provide us when you contact us for help; (d) information you enter into our system when using the Application, such as contact information.
We may also use the information you provided us to contact your from time to time to provide you with important information, required notices and marketing promotions.<br><br>

<h5>Automatically Collected Information </h5>
In addition, the Application may collect certain information automatically, including, but not limited to, the type of mobile device you use, your mobile devices unique device ID, the IP address of your mobile device, your mobile operating system, the type of mobile Internet browsers you use, and information about the way you use the Application. <br><br>
 
<h5>Does the Application collect precise real time location information of the device?</h5>
When you visit the mobile application, we may use GPS technology, Bluetooth Low Energy beacon technology (or other similar technology) to determine your current location in order to determine the building and/or city you are located within and display relevant information based on this data. We reserve the right to share this location information with our partners.
If you do not want us to use your location for the purposes set forth above, you should turn off the location services for the mobile application located in your account settings or in your mobile phone settings and/or within the mobile application. <br><br>
 
<h5>Do third parties see and/or have access to information obtained by the Application?</h5>
Yes. We will share your information with third parties only in the ways that are described in this privacy statement.
We may disclose User Provided and Automatically Collected Information:
<ul>
<li>As required by law, such as to comply with a subpoena, or similar legal process;
<li>When we believe in good faith that disclosure is necessary to protect our rights, protect your safety or the safety of others, investigate fraud, or respond to a government request;
<li>With our trusted services providers who work on our behalf, do not have an independent use of the information we disclose to them, and have agreed to adhere to the rules set forth in this privacy statement.
<li>With other services in order to improve the accuracy or variety of offerings to you. 
<li>If Ignite BLE, LLC is involved in a merger, acquisition, or sale of all or a portion of its assets, you will be notified via email and/or a prominent notice on our Web site of any change in ownership or uses of this information, as well as any choices you may have regarding this information.to advertisers and third party advertising networks and analytics companies as described in the section below
 </ul><br>
<h5>Automatic Data Collection and Advertising</h5>
We may work with analytics companies to help us understand how the Application is being used, such as the frequency and duration of usage. We might work with advertisers and third party advertising networks or third party coupon providers, who need to know how you interact with information provided in the Application. These third parties may use some of the information collected by the Application, including, but not limited to, the unique identification ID of your mobile device and your mobile telephone number. To protect the anonymity of this information, we use an encryption technology to help ensure that these third parties can’t identify you personally. These third parties may also obtain anonymous information about other applications you’ve downloaded to your mobile device, your non-precise location information, longitude and latitude, (e.g., your zip code), and other non- precise location information in order to help analyze and serve anonymous targeted information on the Application. We may also share encrypted versions of information you have provided in order to enable our partners to append other available information about you for analysis. 
If you’d like to opt-out from third party use of this type of information to help serve targeted advertising, please visit the section entitled “Opt-out” below. <br><br>

<h5>Promotions & Surveys</h5> 
In connection with promotions, surveys, or other projects, we may ask you whether you object to our specified data use or sharing. If you opt-out under such circumstances, we will respect your decision. 
<br><br>

<h5>What are my opt-out rights?</h5>
There are multiple opt-out options for users of this Application:    
Opt-out of all information collection by uninstalling the Application: You can stop all collection of information by the Application easily by uninstalling the Application. You may use the standard uninstall processes as may be available as part of your mobile device or via the mobile application marketplace or network. You can also request to opt-out via email, at privacy@igniteble.com <br><br>

<h5>Data Retention Policy, Managing Your Information</h5>
We will retain User Provided data for as long as you use the Application and for a reasonable time thereafter. We will retain Automatically Collected information for up to 24 months and thereafter may store it in aggregate. If you’d like us to delete User Provided Data that you have provided via the Application, please contact us at privacy@igniteble.com and we will respond in a reasonable time. Please note that some or all of the User Provided Data may be required in order for the Application to function properly.<br><br>
 
<h5>Children’s Privacy</h5>
We do not use the Application to knowingly collect any personal information, solicit data from or market to children under the age of 13. If you, a parent or guardian (parental consent) becomes aware that his or her child has provided us with information without your consent, he or she should contact us at privacy@igniteble.com. If you become aware that a child under thirteen (13) has provided us with personal information without parental consent, we will take steps to delete such information from our files, within a reasonable time.<br><br>
 
<h5>Security</h5>
We are concerned about safeguarding the confidentiality of your information. We provide physical, electronic, and procedural safeguards to protect information we process and maintain. For example, we limit access to this information to authorized employees and contractors who need to know that information in order to operate, develop or improve our Application. Please be aware that, although we endeavor provide reasonable security for information we process and maintain, no security system can prevent all potential security breaches.<br><br>
 
<h5>Changes</h5>
This Privacy Policy may be updated from time to time for any reason. We will notify you of any changes to our Privacy Policy by posting the new Privacy Policy here and informing you via email or text message. You are advised to consult this Privacy Policy regularly for any changes, as continued use is deemed approval of all changes. You can check the history of this policy by clicking here.<br><br>
 
<h5>Your Consent</h5>
By using the Application, you are consenting to our processing of your information as set forth in this Privacy Policy now and as amended by us. "Processing,” means using cookies on a computer/hand held device or using or touching information in any way, including, but not limited to, collecting, storing, deleting, using, combining and disclosing information, all of which activities will take place in the United States. If you reside outside the United States your information will be transferred, processed and stored there under United States privacy standards. <br><br>
 
<h5>Contact us</h5>
If you have any questions regarding privacy while using the Application, or have questions about our practices, please contact us via email at privacy@igniteble.com 
<br><br>

<h5>Effective</h5>
May 22, 2015
























                          
                                         
                        </div>
                           

                    
                    <hr>
                    </div>
                	<!--/Post Content -->
                    
                </div>
                 
            	<!-- Blog Post -->          
            
             
                
                                
                
                
                
                
            
            
            </div>
            <!--/Blog Posts Content -->
            
            
            
            
            
            
            
            
            
            <!-- Sidebar -->
            <div id="sidebar">
            
            
            
             
                
                
                
                <!-- Recent Posts Widget 
                <div class="widget recent-posts clearfix">
                
                	<div class="heading"><h5>Recent Posts</h5></div>
                
                    <ul><li><a href="#">Full Page Background Images</a></li></ul>
                    <p class="bottom-line">July 15, 2013</p>
                    <ul><li><a href="#">Designing for WordPress</a></li></ul>
                    <p class="bottom-line">July 15, 2013</p>
                    <ul><li><a href="#">Build Your Own Social Home!</a></li></ul>
                    <p class="bottom-line">July 15, 2013</p>
                    <ul><li><a href="#">Positioning Relative Positioning</a></li></ul>
                    <p class="bottom-line last">July 15, 2013</p>
                    
                </div>
                 Recent Posts Widget -->
                
                
                
         
                
                
                
                <!-- Archives Widget  
                <div class="widget widget_archives clearfix">
                    
                	<div class="heading"><h5>Archives</h5></div>		
                
                    <ul>
                        <li><a title="" href="news201405.html">May 2014</a></li>
                        <li><a title="" href="news201405.html">June 2014</a></li>
                    </ul>
                    
                </div>
            	 Archives Widget -->
            
            
 
 
   
 
 
 
            
            
            </div>
            <!--/Sidebar -->
            
            
            
            
        
        </div>
    	<!--/Container -->
        
    </div>
    <!--/Blog Content -->
    
    
    
    
    
    <!-- Blog Navigation -->
    <div id="blog-footer" class="clearfix">
    	
        <!--/Container  
        <div class="container no-padding">
        
        	<ul class="inner-navigation masonry">
            
            	<li><a href="#"><span><img src="images/prev_article.png" alt=""></span>Prev Page</a></li>
                <li><a href="#"><span><img src="images/next_article.png" alt=""></span>Next Page</a></li>
            
            </ul>
        
    	</div>
    	 /Container -->
    
    </div>
    <!--/Blog Navigation -->
    
    
    
    
    
    <!-- ALL ICON IMAGES
    
    <img src="images/blog-gallery.png" alt=""> <img src="images/blog-quote.png" alt=""> <img src="images/blog-video.png" alt=""> <img src="images/blog-text.png" alt=""> <img src="images/blog-image.png" alt=""> 
    //-->
    
    
    
    
    
    
    
    <!-- Footer -->
    <footer>
				<div class="container no-padding">
        	
            <a id="back-top"><div id="menu_top"><div id="menu_top_inside"></div></div></a>
            
            <ul class="socials-icons">
                <li><a target="_blank" href="http://facebook.com/Igniteble"><img src="/images/facebook.png" alt="" /></a></li>
                <li><a target="_blank" href="http://twitter.com/Igniteble"><img src="/images/twitter.png" alt="" /></a></li>
               
            </ul> 
            
			<p class="copyright">Interface Proximity | Igniteble, LLC - All rights reserved.  
				
				&copy; 2014<script>new Date().getFullYear()>2011&&document.write("-"+new Date().getFullYear());</script>  | <a href="/end-user-privacy-policy.php">End User Mobile App Privacy Policy</a> | <a href="/interface/index.php">Log In</a></p>
            
		</div>	</footer>
	<!-- Footer -->
    

    
	
	<script src='http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.js'></script>
    <script src="js/jquery.sticky.js"></script>	    
	<script src="js/jquery.easing-1.3.pack.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/jquery.parallax-1.1.3.js" type="text/javascript"></script>
	<script src="js/appear.js" type="text/javascript" ></script>
	<script src="js/modernizr.js" type="text/javascript"></script>
	<script src="js/jquery.prettyPhoto.js" type="text/javascript"></script>
    <script src="js/isotope.js" type="text/javascript"></script>
    <script src="js/jquery.bxslider.min.js"></script>
    <script src="js/jquery.cycle.all.js" type="text/javascript" charset="utf-8"></script>
	<script src="js/jquery.maximage.js" type="text/javascript" charset="utf-8"></script>
    <script src="js/sscr.js"></script>
    <script src="js/skrollr.js"></script>
    <script src="http://maps.google.com/maps/api/js?sensor=false" type="text/javascript"></script>    
	<script src="js/scripts.js" type="text/javascript"></script>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-6770565-26', 'auto');
  ga('send', 'pageview');

</script>    
    
	
	
	</body>
</html>